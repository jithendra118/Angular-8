import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {User} from "../model/user.model";
import {Observable} from "rxjs/index";
import {ApiResponse} from "../model/api.response";
import { ImageModel } from '../model/image.model';

const httpOptions = {
  responseType: 'arraybuffer' as 'json'
  // 'responseType'  : 'blob' as 'json'        //This also worked
};
@Injectable()
export class ApiService {
  constructor(private http: HttpClient) { }
  baseUrl: string = 'http://localhost:8083/users/';
  imageSave(uploadImageData): Observable<ImageModel> {
    return this.http.post<ImageModel>('http://localhost:8083/image/upload', uploadImageData);
  }
  login(loginPayload) : Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8083/' + 'token/generate-token', loginPayload);
  }

  signUp(signUpLoad): Observable<ApiResponse> {
    return this.http.post<ApiResponse>('http://localhost:8083/signUp', signUpLoad);
  }

  getUsers() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl);
  }
  getUsersAll() : Observable<User[]> {
    return this.http.get<User[]>('http://localhost:8083/users/getALList');
  }
  generateDocumentReport(): Observable<any> {
    return this.http.get('http://localhost:8083/report/view/',
      { responseType: 'arraybuffer'});
    }
  getUserById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl + id);
  }

  createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl, user);
  }

  updateUser(user: User): Observable<ApiResponse> {
    return this.http.put<ApiResponse>(this.baseUrl + user.id, user);
  }

  deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl + id);
  }
}

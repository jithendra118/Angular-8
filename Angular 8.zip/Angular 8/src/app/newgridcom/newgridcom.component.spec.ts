import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewgridcomComponent } from './newgridcom.component';

describe('NewgridcomComponent', () => {
  let component: NewgridcomComponent;
  let fixture: ComponentFixture<NewgridcomComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewgridcomComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewgridcomComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

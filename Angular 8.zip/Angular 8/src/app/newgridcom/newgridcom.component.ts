import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { orderDetailsDum } from './data';
import { EditService, ToolbarService, PageService, DialogEditEventArgs, SaveEventArgs } from '@syncfusion/ej2-angular-grids';
import { DataUtil } from '@syncfusion/ej2-data';
import { FormBuilder, FormGroup } from '@angular/forms';
import { User } from '../model/user.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../service/api.service';

@Component({
  selector: 'app-newgridcom',
  templateUrl: './newgridcom.component.html',
  styleUrls: ['./newgridcom.component.css'],
  providers: [ToolbarService, EditService, PageService]
})
export class NewgridcomComponent {
    public anyData : any;
    jsonData : string[] =[];
    user : User;
    users : User[]=[];
  public data: Object[];
  public editSettings: Object;
  public toolbar: string[];
  public pageSettings: Object;
  public shipCityDistinctData: Object[];
  public usernameData: Object[];
  public shipCountryDistinctData: Object[];
  public orderData: IOrderModel;
  public userData: IUser;
  @ViewChild('orderForm', { static: true })
  public orderForm: FormGroup;
  @ViewChild('OrderID' , { static: true })
  public orderID: ElementRef;
  @ViewChild('CustomerName', { static: true })
  public customerName: ElementRef;
  @ViewChild('id' , { static: true })
  public id: ElementRef;
  @ViewChild('username', { static: true })
  public username: ElementRef;
  @ViewChild('firstName', { static: true })
  public firstName: ElementRef;
  @ViewChild('lastName', { static: true })
  public lastName: ElementRef;
  @ViewChild('salary', { static: true })
  public salary: ElementRef;
  constructor(private router: Router, private route: ActivatedRoute, private formBuilder: FormBuilder, private apiService: ApiService) { 

}
  public ngOnInit(): void {
    this.apiService.getUsers()
    .subscribe( data => {
      this.users = data.result;
      for (let i in this.users) {
        this.users[i].retrievedImage="";
        this.anyData = JSON.stringify(this.users[i]);
        this.jsonData[i]=this.jsoncheck(this.anyData);
        
      }
      this.data = this.jsonData;
      this.shipCityDistinctData = DataUtil.distinct(this.data, 'salary', true);
      this.usernameData = DataUtil.distinct(this.data, 'username', true);
    });
    
    
      this.editSettings = { allowEditing: true, allowAdding: true, allowDeleting: true };
      this.toolbar = ['Add', 'Edit', 'Delete', 'Update', 'Cancel'];
      this.pageSettings = { pageCount: 5};
       
      /*this.shipCountryDistinctData = DataUtil.distinct(orderDetails, 'ShipCountry', true ); */
  }

  jsoncheck(data: any): any{
    const orderDetails: Object[] = JSON.parse(data, (field, value) => {
        let dupValue = value;
        if (typeof value === 'string' && /^(\d{4}\-\d\d\-\d\d([tT][\d:\.]*){1})([zZ]|([+\-])(\d\d):?(\d\d))?$/.test(value)) {
            let arr = dupValue.split(/[^0-9]/);
            value = new Date(parseInt(arr[0], 10), parseInt(arr[1], 10) - 1, 
            parseInt(arr[2], 10), parseInt(arr[3], 10), parseInt(arr[4], 10), parseInt(arr[5], 10));
        }
        return value;
     });
     return orderDetails;
  }
  
  reportPDF() {
    this.apiService.generateDocumentReport().subscribe(response => {
      let file = new Blob([response.data], { type: 'application/pdf' });
      let fileURL = window.URL.createObjectURL(file);
      window.top.open(fileURL, '_blank');
    }, error => {
    })
    }
  
  actionBegin(args: SaveEventArgs): void {
      if (args.requestType === 'beginEdit' || args.requestType === 'add') {
          this.userData = Object.assign({}, args.rowData);
      }
      if (args.requestType === 'save') {
          if (this.orderForm.valid) {
              args.data = this.userData;
          } else {
              args.cancel = true;
          }
      }
  } 

  actionComplete(args: DialogEditEventArgs): void {
      if (args.requestType === 'beginEdit' || args.requestType === 'add') {
          // Set initail Focus
          if (args.requestType === 'beginEdit') {
              (args.form.elements.namedItem('username') as HTMLInputElement).focus();
          } else if (args.requestType === 'add') {
              (args.form.elements.namedItem('id') as HTMLInputElement).focus();
          }

      }
  }

  public focusIn(target: HTMLElement): void {
      target.parentElement.classList.add('e-input-focus');
  }

  public focusOut(target: HTMLElement): void {
      target.parentElement.classList.remove('e-input-focus');
  }

}

export interface IOrderModel {
  OrderID?: number;
  CustomerName?: string;
  ShipCity?: string;
  OrderDate?: Date;
  Freight?: number;
  ShipCountry?: string;
  ShipAddress?: string;
}

export interface IUser{
    id?: number;
  username?: string;
  firstName?: string;
  lastName?: string;
  salary?: number; 
}
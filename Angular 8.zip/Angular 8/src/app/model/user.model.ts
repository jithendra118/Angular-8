import { ImageModel } from './image.model';

export class User {

  id: number;
  username: string;
  firstName: string;
  lastName: string;
  salary: number;
  age: number;
  retrievedImage: string;
  idImage : ImageModel;
  isSelected: boolean = false ; 


}

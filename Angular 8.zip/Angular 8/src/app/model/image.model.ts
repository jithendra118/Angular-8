export class ImageModel {

    id: number;
    picByte: any;
    type: string;
    name: string;
  }
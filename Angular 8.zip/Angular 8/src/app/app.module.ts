import { DropDownListAllModule } from '@syncfusion/ej2-angular-dropdowns';

import { DatePickerAllModule } from '@syncfusion/ej2-angular-calendars';

import { ToolbarModule } from '@syncfusion/ej2-angular-navigations';

import { NumericTextBoxAllModule } from '@syncfusion/ej2-angular-inputs';

import { GridAllModule } from '@syncfusion/ej2-angular-grids';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppComponent } from './app.component';
import { NewgridcomComponent } from './newgridcom/newgridcom.component';
import { AppRoutingModule } from './app.routing';
import { LoginComponent } from './login/login.component';
import {ApiService} from "./service/api.service";
import { HttpClientModule,HTTP_INTERCEPTORS} from "@angular/common/http";
import { TokenInterceptor } from './core/interceptor';

@NgModule({ 
    declarations: [ 
        AppComponent,
        NewgridcomComponent, 
        LoginComponent ],
    imports: [ 
        CommonModule,
         ToolbarModule, 
         HttpClientModule,
         GridAllModule,
         AppRoutingModule, 
         BrowserModule, 
         NumericTextBoxAllModule,  
         DatePickerAllModule, 
         DropDownListAllModule, 
         ReactiveFormsModule, 
         FormsModule], 
    providers: [ApiService, {provide: HTTP_INTERCEPTORS,
        useClass: TokenInterceptor,
        multi : true}], 
    bootstrap: [AppComponent]
})
export class AppModule { }




